from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime, date
import re

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-to-a-long-random-secret"
DB_PATH = Path(__file__).with_name("zora_events.db")

def get_db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS inquiries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT NOT NULL,
                event_type TEXT NOT NULL,
                event_date TEXT NOT NULL,
                location TEXT NOT NULL,
                guests INTEGER NOT NULL,
                budget TEXT NOT NULL,
                requirements TEXT,
                created_at TEXT NOT NULL
            )
        """)

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/inquiries")
def create_inquiry():
    data = request.get_json(silent=True) or request.form
    fields = ["full_name", "phone", "email", "event_type", "event_date",
              "location", "guests", "budget"]
    missing = [field for field in fields if not str(data.get(field, "")).strip()]
    if missing:
        return jsonify(success=False, message="Please complete all required fields."), 400

    full_name = str(data["full_name"]).strip()
    phone = str(data["phone"]).strip()
    email = str(data["email"]).strip()
    location = str(data["location"]).strip()
    requirements = str(data.get("requirements", "")).strip()

    if len(full_name) < 2 or len(full_name) > 100:
        return jsonify(success=False, message="Please enter a valid name."), 400
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        return jsonify(success=False, message="Please enter a valid email address."), 400
    if len(re.sub(r"\D", "", phone)) < 7:
        return jsonify(success=False, message="Please enter a valid phone number."), 400
    try:
        event_day = date.fromisoformat(str(data["event_date"]))
        guests = int(data["guests"])
        if guests < 1 or guests > 100000:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify(success=False, message="Please check the event date and guest count."), 400
    if event_day < date.today():
        return jsonify(success=False, message="The event date cannot be in the past."), 400

    with get_db() as db:
        db.execute("""
            INSERT INTO inquiries
            (full_name, phone, email, event_type, event_date, location, guests,
             budget, requirements, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            full_name, phone, email, str(data["event_type"]).strip(),
            event_day.isoformat(), location, guests, str(data["budget"]).strip(),
            requirements, datetime.now().isoformat(timespec="seconds")
        ))
    return jsonify(success=True, message="Thank you! Your event inquiry has been received. Our team will be in touch soon.")

@app.get("/health")
def health():
    return jsonify(status="ok", app="ZORA LANKA EVENTS")

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
