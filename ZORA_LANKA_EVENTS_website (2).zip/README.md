# ZORA LANKA EVENTS

A responsive luxury event-planning website built with HTML, CSS, JavaScript, Python Flask and SQLite.

## Requirements
- Python 3.9 or newer
- pip

## Run locally

1. Extract the ZIP file and open a terminal in the `zora_lanka_events` folder.
2. Create and activate a virtual environment (recommended):

   **Windows**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the website:

   ```bash
   python app.py
   ```

5. Open http://127.0.0.1:5000 in your browser.

The SQLite database (`zora_events.db`) is created automatically when the app starts. Event inquiry submissions are saved there.

## Before publishing
- Replace the placeholder phone number, WhatsApp number and email address in `templates/index.html`.
- Update the social media links and add your Google Maps embed.
- Replace demo counters and sample testimonials with verified information.
- Replace stock photography with your own event portfolio images where possible.
- Change `SECRET_KEY` in `app.py` to a secure random value.
- For production, run with a production WSGI server (for example Gunicorn) and configure HTTPS, backups and hosting environment variables.
- The current inquiry endpoint stores submissions in SQLite. Add email notifications or an admin dashboard if you need them.

## Main files
- `app.py` — Flask server and booking API
- `templates/index.html` — page structure and content
- `static/css/style.css` — styling and responsive layouts
- `static/js/script.js` — navigation, gallery, slider and form interactions
- `zora_events.db` — created automatically at runtime
