document.addEventListener("DOMContentLoaded", () => {
  const loader = document.getElementById("loader");
  window.addEventListener("load", () => setTimeout(() => loader.classList.add("done"), 350));
  setTimeout(() => loader.classList.add("done"), 2200);

  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("navLinks");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
    toggle.innerHTML = open ? '<i class="bi bi-x-lg"></i>' : '<i class="bi bi-list"></i>';
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.innerHTML = '<i class="bi bi-list"></i>';
  }));

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.12});
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

  document.querySelectorAll(".filter").forEach(button => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
      button.classList.add("active");
      const category = button.dataset.filter;
      document.querySelectorAll(".gallery-item").forEach(item => {
        item.classList.toggle("hidden", category !== "all" && item.dataset.category !== category);
      });
    });
  });

  const lightbox = document.getElementById("lightbox");
  const lightboxImage = document.getElementById("lightboxImage");
  document.querySelectorAll(".gallery-item").forEach(item => item.addEventListener("click", () => {
    lightboxImage.src = item.dataset.full;
    lightboxImage.alt = item.querySelector("img").alt;
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
  }));
  function closeLightbox() {
    lightbox.classList.remove("open");
    lightbox.setAttribute("aria-hidden", "true");
    lightboxImage.src = "";
  }
  document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
  lightbox.addEventListener("click", e => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeLightbox(); });

  const reviews = [...document.querySelectorAll(".testimonial")];
  let reviewIndex = 0;
  function showReview(index) {
    reviewIndex = (index + reviews.length) % reviews.length;
    reviews.forEach((review, i) => review.classList.toggle("active", i === reviewIndex));
    document.getElementById("reviewCount").textContent = `${String(reviewIndex + 1).padStart(2, "0")} / ${String(reviews.length).padStart(2, "0")}`;
  }
  document.getElementById("prevReview").addEventListener("click", () => showReview(reviewIndex - 1));
  document.getElementById("nextReview").addEventListener("click", () => showReview(reviewIndex + 1));
  let sliderTimer = setInterval(() => showReview(reviewIndex + 1), 6500);
  document.querySelector(".testimonial-slider").addEventListener("mouseenter", () => clearInterval(sliderTimer));
  document.querySelector(".testimonial-slider").addEventListener("mouseleave", () => sliderTimer = setInterval(() => showReview(reviewIndex + 1), 6500));

  const dateInput = document.querySelector('input[name="event_date"]');
  const today = new Date();
  dateInput.min = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split("T")[0];

  const form = document.getElementById("bookingForm");
  const message = document.getElementById("formMessage");
  form.addEventListener("submit", async e => {
    e.preventDefault();
    if (!form.reportValidity()) return;
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    submit.innerHTML = 'Sending inquiry <i class="bi bi-arrow-repeat"></i>';
    message.textContent = "";
    message.className = "form-message";
    try {
      const payload = Object.fromEntries(new FormData(form).entries());
      const response = await fetch("/api/inquiries", {
        method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)
      });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.message || "Unable to submit your inquiry.");
      message.textContent = result.message;
      message.classList.add("success");
      form.reset();
      dateInput.min = new Date().toISOString().split("T")[0];
    } catch (error) {
      message.textContent = error.message || "Something went wrong. Please try again.";
      message.classList.add("error");
    } finally {
      submit.disabled = false;
      submit.innerHTML = 'Submit Event Inquiry <i class="bi bi-arrow-up-right"></i>';
    }
  });
});
